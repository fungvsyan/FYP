<?php
require 'vendor/autoload.php';
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;
$bucketName = 'fyp-demo-key-collection-bucket';
$IAM_KEY = 'AKIATSG5DXQPSVJUNKL6';
$IAM_SECRET = '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';

try {
    $s3 = S3Client::factory(
        array(
            'credentials' => array(
                'key' => $IAM_KEY,
                'secret' => $IAM_SECRET
            ),
            'version' => 'latest',
            'region'  => 'ap-southeast-1'
        )
    );
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
// For this, I would generate a unqiue random string for the key name. But you can do whatever.
$keyName = 'test_example/' . basename($_FILES["fileToUpload"]['name']);
$pathInS3 = 'https://s3.ap-southeast-1.amazonaws.com/' . $bucketName . '/' . $keyName;

try {
    $file = $_FILES["fileToUpload"]['tmp_name'];
    $s3->putObject(
        array(
            'Bucket'=>$bucketName,
            'Key' =>  $keyName,
            'SourceFile' => $file,
            'StorageClass' => 'REDUCED_REDUNDANCY'
        )
    );
} catch (S3Exception $e) {
    die('Error:' . $e->getMessage());
} catch (Exception $e) {
    die('Error:' . $e->getMessage());
}

header("Location: http://b2fyp.ap-southeast-1.elasticbeanstalk.com/FYP/uploadpage.html"); /* Redirect browser */
exit();
echo "";

?>
